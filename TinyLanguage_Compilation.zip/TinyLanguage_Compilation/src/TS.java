import java.util.ArrayList;

public class TS
{
    static public class Element {
        String name;
        int type;
        public Element(String name,  int type) {
            this.name = name; // on rajoute pas val,on peut convertir sur place et calculer avc pr eviter de parcourir ka TS pr trouver la valeur + on a pas l'incrementation/decrementation on a pas besoin de la valeur précedente
            this.type = type;

        }

        public Element(Element element) {
            this.name = element.name;
            this.type=element.type;
        }


        // 1:int 2:float




        @Override
        public String toString()
        {

            return "var: " + name + " type: " + ((type==1)?"int":"float") + " var status: " ;
        }
    }


    public ArrayList<Element> L = new ArrayList<Element>();


    public Element getElement(String name)
    {
        for (int i = 0; i < L.size(); i++) {
            if(L.get(i).name.compareTo(name)==0)
                return L.get(i);
        }
        return null;
    }
 // si l elet dans  la ts n est pas declarer elle retoune faux
    public boolean containsElement(String name)
    {
        return getElement(name) != null;
    }

    public void addElement(Element e)
    {
        L.add(e);
    }

    public void deleteElement(String name)
    {
        for (int i = 0; i < L.size(); i++) {
            if(L.get(i).name.compareTo(name)==0)
            {
                deleteElement(L.get(i));
                return;
            }
        }
    }

    public void deleteElement(Element e) // essayer de mettre ça dans deleteElement
    {
        L.remove(e);
    }


    public Element getElement(int i)
    {
        return L.get(i);
    }

}
