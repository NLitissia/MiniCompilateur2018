import org.antlr.v4.runtime.*;
import org.antlr.v4.gui.TestRig;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;


import java.util.LinkedList;
import java.util.List;

public class Listener extends TinyBaseListener {
    //l objet table pour pouvoir ajouter dans la ts
    private TS table = new TS();
    LinkedList<String> erreur = new LinkedList<>();
    //elle nous permet de parcourir l'arbre et a chaque regle on fait un traitement
    //ajout dans la ts par exemple
    //exitdv parceque je doit recuperer le type 0 si float et 1  sinon
    public void exitDv(TinyParser.DvContext ctx) {
        //dv : type p ';'  | type p ';' dv
        int k;
        if (ctx.type().getText().equals("intcompil")) {
            k = 1; // intcompil = 1
        } else {
            k = 0; // dans la ts floatcompil=0

        }

        TinyParser.PContext vars= ctx.p();
        for(vars = vars.p();vars != null;)
        {
            // parceque on peut avoir plusieur declartion en meme temps
            String nom = vars.getChild(0).getText();
            if(!table.containsElement(nom))
            {
                table.addElement(new TS.Element(new TS.Element(nom,k)));
            }
            else
            {
               erreur.add("Erreur double declaration de la variable "+nom+".");

            }
        }

    }
   public void exitAff(TinyParser.AffContext ctx) {
        /*aff : oprt '=' oprt  	';'	; mais il faut verifier la compatibilittt*/
  /*   TinyParser.AffContext name = (TinyParser.AffContext) ctx.oprt();
        String idff = name.getText();

       if(!table.containsElement(idff))
       {
           erreur.add("Erreur double declaration de la variable "+idff+".");
       }
       else

       {
           //if(types.get)
         // if((getCtxType(ctx.exp()),table.getElement(ctx.identifier().getText()).type)){}
       }*/

       }




}
